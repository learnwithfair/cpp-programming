#include<iostream>
#include<conio.h>
#include<iomanip>
using namespace std;
int main()
{
    int n,m,r;
    cout<<"Enter First number : ";
    cin>>n;
    cout<<"Enter First number : ";
    cin>>m;
    r=n|m;
    //i00
    //i0i
    //-----
    //i0i
    cout<<"Result of the Bit wise OR gate "<<r;
    getch();
}
