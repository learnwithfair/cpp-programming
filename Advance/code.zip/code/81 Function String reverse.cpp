#include<iostream>
#include<conio.h>
#include<stdio.h>
#include<string.h>
using namespace std;
void dis(char str[],int len)
{
    char str2[len];
    int i,j;

    for(i=len-1,j=0; i>=0; i--,j++)
    {
        str2[j]=str[i];

    }
    str2[j]='\0';
    cout<<"Reverse String is "<<str2<<"\n\n";


}
main()
{
    char str[40];
    int len;
    while(1)
    {
        cout<<"Enter any String : ";
        gets(str);
        len=strlen(str);
        cout<<"\nString is "<<str<<"\n\n";
        dis(str,len);

    }
    getch();
}
