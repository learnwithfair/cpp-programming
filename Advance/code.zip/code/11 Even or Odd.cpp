#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    int num;
    cout<<"Enter any number : ";
    while((cin>>num)!=0)
    {
        if(num%2==0)
            cout<<"The number is Even"<<endl;
        else
            cout<<"The number is Odd"<<endl;
        cout<<"Enter any number : ";

    }
    getch();
}
