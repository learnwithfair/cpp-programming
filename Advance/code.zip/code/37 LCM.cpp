#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    int num1,num2,GCD,LCM,n1,n2;
    cout<<"Enter First number : ";
    cin>>n1;
    cout<<"Enter Second number : ";
    cin>>n2;
    num1=n1;
    num2=n2;
    while(num2!=0)
    {
        GCD=num1%num2;
        num1=num2;
        num2=GCD;
    }
    GCD=num1;
    LCM=(n1*n2)/GCD;
    cout<<"GCD Value is "<<GCD;
    cout<<"\nLCM value is "<<LCM;
    getch();
}
