#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    int n1,n2,fibo,n;
    cout<<"Enter any term : ";
    while((cin>>n)!=0)
    {
        cout<<"\nFibonacci series is : ";
        n1=-1;
        n2=1;
        while(n!=0)
        {
            fibo=n1+n2;
            cout<<fibo<<" ";
            n1=n2;
            n2=fibo;
            n--;
        }
    cout<<"\n\nEnter any term : ";

    }
    getch();
}
