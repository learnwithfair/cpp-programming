#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    float num1,num2,max;
    float *p1,*p2;
    while(1)
    {
        cout<<"Enter First number : ";
        cin>>num1;
        cout<<"Enter Second number : ";
        cin>>num2;
        p1=&num1;
        p2=&num2;
        if(*p1>*p2)
            cout<<"Maximum number is "<<*p1<<"\n\n";
        else if(*p1==*p2)
            cout<<"These numbers are same."<<"\n\n";
        else
            cout<<"Maximum number is "<<*p2<<"\n\n";
    }

    getch();

}
