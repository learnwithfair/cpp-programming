#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    int i,n,r,npr=1,n1;
    cout<<"Enter Value of n : ";
    cin>>n;
    cout<<"Enter Value of r : ";
    cin>>r;
    n1=n;
    for(i=1;i<=r;i++)
    {
        npr=npr*n;
        n--;
    }
    cout<<n1<<"P"<<r<<" value is "<<npr;
    getch();
}
