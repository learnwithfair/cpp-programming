#include<iostream>
#include<conio.h>
#include<iomanip>
using namespace std;
double pi =3.1416;
double dis(double r)
{
    double area,pi=4;
    return area=::pi*r*r;
}
int main()
{
    double r;
    cout<<"Enter Circle Radius : ";
    cin>>r;
    cout<<fixed<<setprecision(2);
    cout<<"Circle area is "<<dis(r)<<endl;
    getch();
}
