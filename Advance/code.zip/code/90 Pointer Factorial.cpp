#include<iostream>
#include<conio.h>
using namespace std;
main()
{


    while(1)
    {
        int n,i,fact=1;
        int *p;
        cout<<"Enter your number : ";
        cin>>n;
        p=&n;
        for(i=1; i<=*p; i++)
        {
            fact=fact*i;
        }
        cout<<"The number of the Factorial Value is "<<fact<<"\n\n";
    }

    getch();
}
