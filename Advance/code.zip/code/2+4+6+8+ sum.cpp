#include<iostream>
#include<conio.h>
#include<math.h>
using namespace std;
int main()
{
    int n,sum,i,a;
    cout<<"Enter any term : ";
    while((cin>>n)!=0)
    {
        a=2;
        sum=0;
        for(i=1; i<=n; i++)
        {
            sum=sum+a;
            a=a+2;
        }
        cout<<"Sum of the value "<<sum;
        cout<<"\nEnter any term : ";
    }
    getch();
}

