#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    int a[20][20],row,col,i,j;
    cout<<"Enter number of Row : ";
    cin>>row;
    cout<<"\n\nEnter number of Column : ";
    cin>>col;
    cout<<"\n\nEnter Element : \n";
    for(i=0;i<row;i++)
    {
        cout<<"Enter Element for "<<i+1<<" number Row : \n";
        for(j=0;j<col;j++)
        {
            cout<<"A["<<i<<"]["<<j<<"] : ";
            cin>>a[i][j];
        }
    }
    cout<<"\n\nA Matrix is : \n\t\t";
    for(i=0;i<row;i++)
    {
        for(j=0;j<col;j++)
        {
            cout<<a[i][j]<<" ";
        }
        cout<<endl<<"\t\t";
    }
    getch();

}
