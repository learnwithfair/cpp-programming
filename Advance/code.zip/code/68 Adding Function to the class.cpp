#include<iostream>
#include<conio.h>
using namespace std;
class student
{
public:
    int id;
    float gpa;
    void dis()
    {
        cout<<id<<" "<<gpa<<endl;
    }
    void setvalue(int x,float y)

    {
            id=x;
            gpa=y;
    }
};
int main()
{
    student rohim,ruy;
    rohim.setvalue(202,3.25);
    rohim.dis();

    ruy.setvalue(203,3.92);
    ruy.dis();
    getch();

}
