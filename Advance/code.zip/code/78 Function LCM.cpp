#include<iostream>
#include<conio.h>
using namespace std;
int dis(int num1,int num2)

{
    int tem,gcd,lcm,n1,n2;
    n1=num1;
    n2=num2;
    while(num2!=0)
    {
        tem=num1%num2;
        num1=num2;
        num2=tem;
    }
    gcd=num1;
    return lcm=(n1*n2)/gcd;
}
int main()
{
    int num1,num2;
    while(1)
    {
        cout<<"Enter First number : ";
        cin>>num1;
        cout<<"Enter second number : ";
        cin>>num2;
        cout<<"These number of the LCM is "<<dis(num1,num2)<<"\n\n";
    }
    getch();
}

