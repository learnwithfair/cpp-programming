#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    int num[30],i,n,p,pos,j;
    cout<<"How many number : ";
    while((cin>>n)!=0)
    {
        pos=0;
        j=0;
        cout<<"\nEnter any Elements : ";
        for(i=0; i<n; i++)
        {
            cin>>num[i];

        }
        cout<<"\nArray numbers are : ";
        for(i=0; i<n; i++)
            cout<<num[i]<<" ";
        cout<<"\n\nEnter Delete number : ";
        cin>>p;

        for(i=0; i<n; i++)
        {

            if(num[i]==p)
            {
                pos++;
                continue;

            }

            else
            {
                num[j]=num[i];
                j++;
            }

        }

        for(j=0; j<n-1; j++)
        {
            if(pos==0)
            {
                cout<<"\n\nDelete number is not Find";
                break;
            }
            else
            {
                if(j==0)
                    cout<<"\n\nArray numbers are : ";
                cout<<num[j]<<" ";
            }
        }

        cout<<"\n\nHow many number : ";
    }
    getch();
}
