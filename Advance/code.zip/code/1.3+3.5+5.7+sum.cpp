#include<iostream>
#include<conio.h>
#include<math.h>
using namespace std;
int main()
{
    int n,sum,i,a,b;
    cout<<"Enter any term : ";
    while((cin>>n)!=0)
    {
        a=1;
        b=3;
        sum=0;
        for(i=1; i<=n; i++)
        {
            sum=sum+a*b;
            a=a+2;
            b+=2;
        }
        cout<<"Sum of the value "<<sum;
        cout<<"\nEnter any term : ";
    }
    getch();
}

