#include<iostream>
#include<stdio.h>
#include<conio.h>
#include<string.h>
using namespace std;
main()
{
    while(1)
    {
        char str[20],*p;
        int i,vowel,consonant,digit,other,word;
        i=vowel=consonant=digit=other=word=0;
        cout<<"Enter any string : ";
        gets(str);
        strlwr(str);
        p=&str[0];
        while(str[i]!='\0')
        {
            if(*p=='a'||*p=='e'||*p=='i'||*p=='o'||*p=='u')
                vowel++;
            else if(*p>='a'&&*p<='z')
                consonant++;
            else if(*p>='0'&&*p<='9')
                digit++;
            else if(*p==' ')
                word++;
            else
                other++;
            i++;
            p++;
        }
        word++;
        cout<<"Vowel number is "<<vowel<<endl;
        cout<<"Consonant number is "<<consonant<<endl;
        cout<<"Digit number is "<<digit<<endl;
        cout<<"Word number is "<<word<<endl;
        cout<<"Other number is "<<other<<endl<<endl;
    }
    getch();

}
