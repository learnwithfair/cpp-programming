#include<iostream>
#include<conio.h>
#include<iomanip>
using namespace std;
int main()
{
    int mark;
    cout<<"Enter any mark : ";
    while((cin>>mark)!=0)
    {
        if(mark>100||mark<0)
        {
            cout<<"Invalid result"<<endl;
        }
        else if(mark>=60)
        {
            cout<<"First Division"<<endl;
        }
        else if(mark>=48)
        {
            cout<<"Second Division"<<endl;
        }
        else if(mark>=33)
        {
            cout<<"Third Division"<<endl;
        }
        else
            cout<<"Fail"<<endl;
            cout<<"Enter any mark : ";
    }
    getch();
}
