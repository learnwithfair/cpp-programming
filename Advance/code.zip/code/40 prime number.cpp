#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    int num,i;
    cout<<"Enter any number : ";
    while((cin>>num)!=0)
    {
        cout<<endl;
        for(i=2; i<=num; i++)
        {
            if(num%i==0)
                break;
        }
        if(i==num)
            cout<<"This number is Prime number ";
        else
            cout<<"This number is not Prime number ";
            cout<<"\n\nEnter any number : ";

    }
    getch();
}
