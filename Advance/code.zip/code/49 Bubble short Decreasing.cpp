#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    int a[30],i,j,tem,n;
    cout<<"How many number : ";
    while((cin>>n)!=0)
    {
        cout<<"\n\nEnter Elements : ";
        for(i=0; i<n; i++)
            cin>>a[i];
        cout<<"\n\narray numbers are : ";
        for(i=0; i<n; i++)
            cout<<a[i]<<" ";
        for(i=0; i<n-1; i++)
        {
            for(j=i+1; j<n; j++)
            {
                if(a[i]<a[j])
                {
                    tem=a[i];
                    a[i]=a[j];
                    a[j]=tem;
                }
            }
        }
        cout<<"\n\nDecreasing array numbers : ";
        for(i=0; i<n; i++)
        {
            cout<<a[i]<<" ";
        }
        cout<<"\n\nHow many number : ";
    }
    getch();
}
