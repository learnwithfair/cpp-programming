#include<iostream>
#include<string.h>
#include<stdio.h>
#include<conio.h>
using namespace std;
class student
{
public:
    string name;
    int id;
    float gpa;
};
int main()
{
    student raju[30];
    int i,n;
    cout<<"How many student : ";
    cin>>n;
    for(i=0; i<n; i++)
    {
        cout<<"\n\nEnter "<<i+1<<" number student Information : \n";
        cout<<"Enter your Name : ";
        cin.ignore();
        getline(cin,raju[i].name);
        //gets(raju[i].name);
        cout<<"Enter your ID : ";
        cin>>raju[i].id;
        cout<<"Enter your GPA : ";
        cin>>raju[i].gpa;
    }
    for(i=0; i<n; i++)
    {
        cout<<"\n\n"<<i+1<<" number student Information : \n";
        cout<<"Name : "<<raju[i].name<<endl;
        cout<<"ID : "<<raju[i].id<<endl;
        cout<<"GPA : "<<raju[i].gpa<<endl;

    }

    getch();

}
