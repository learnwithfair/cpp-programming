#include<iostream>
#include<conio.h>
using namespace std;
int dis(int n)
{
    int sum=0,tem;
    while(n>9)
    {

        while(n!=0)
        {
            tem=n%10;
            sum=sum+tem;
            n=n/10;
        }
        n=sum;
        sum=0;

    }
    return n;
}
int main()
{
    int n;
    while(1)
    {
        cout<<"Enter your number : ";
        cin>>n;
        cout<<"The number of Digital Root is "<<dis(n)<<"\n\n";
    }
    getch();
}
