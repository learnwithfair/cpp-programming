#include<iostream>
#include<stdio.h>
#include<conio.h>
#include<string.h>
using namespace std;
int main()
{
    char str[20];
    char str2[20],i,j,len;
    cout<<"Enter any String : ";
    gets(str);

    len=strlen(str);
    for(i=len-1,j=0; i>=0; j++,i--)
    {
        str2[j]=str[i];
    }
    str2[j]='\0';
    cout<<"Reverse String is ";
    i=0;
    while(str2[i]!='\0')
    {
        cout<<str2[i];
        i++;
    }

    //cout<<"\nEnter any string : ";
    getch();
}
