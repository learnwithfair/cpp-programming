#include<iostream>
#include<conio.h>
using namespace std;
int dis(int n,int r)
{
    int i,npr=1;
    for(i=1; i<=r; i++)
    {
        npr=npr*n;
        n--;
    }
    return npr;
}
int main()
{
    int n,r;
    while(1)
    {
        cout<<"Enter value of n : ";
        cin>>n;
        cout<<"Enter value of r : ";
        cin>>r;
        cout<<n<<"P"<<r<<" value is "<<dis(n,r)<<"\n\n";
    }
    getch();

}
