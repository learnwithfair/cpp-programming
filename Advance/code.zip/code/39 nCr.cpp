#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    int n,r,ncr,n1,fact=1,npr=1,i;
    cout<<"Enter value of n : ";
    cin>>n;
    cout<<"Enter value of r : ";
    cin>>r;
    n1=n;
    for(i=1;i<=n;i++)
    {
        npr=npr*n;
        n--;
    }
    for(i=1;i<=r;i++)
    {
        fact=fact*i;
    }
    ncr=npr/fact;
    cout<<n1<<"C"<<r<<" Value is "<<ncr;
    getch();
}
