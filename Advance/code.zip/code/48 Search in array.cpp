#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    int a[30],b[30],i,j,pos,r,n;
    cout<<"How many number : ";
    while((cin>>n)!=0)
    {
        pos=0;
        j=0;
        cout<<"\n\nEnter Elements : ";
        for(i=0; i<n; i++)
        {
            cin>>a[i];
        }
        cout<<"\n\narray numbers are : ";
        for(i=0; i<n; i++)
        {
            cout<<a[i]<<" ";
        }
        cout<<"\n\nEnter search Element : ";
        cin>>r;
        for(i=0; i<n; i++)
        {
            if(r==a[i])
            {
                pos++;
                b[j]=i+1;
                j++;

            }

        }
        if(pos!=0)
        {
            cout<<"\n\nThe number is Find ";
            for(i=0; i<j; i++)
            {
                cout<<b[i]<<", ";
            }
            cout<<"number position in array.";
        }
        else
            cout<<"\n\nThis number is not Find in array.";

        cout<<"\n\nHow many number : ";
    }
    getch();
}
