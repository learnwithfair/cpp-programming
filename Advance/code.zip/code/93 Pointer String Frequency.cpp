#include<iostream>
#include<stdio.h>
#include<conio.h>
#include<string.h>
using namespace std;
main()
{
    while(1)
    {
        char str[20],*p,ch;
        int i,count=0;
        cout<<"Enter any String : ";
        gets(str);
        strlwr(str);
        for(ch='a'; ch<='z'; ch++)
        {
            i=0;
            p=&str[0];
            while(str[i]!='\0')
            {
                if(ch==*p)
                {
                    count++;

                }
                i++;
                p++;

            }
            if(count!=0)
            {
                cout<<ch<<" = "<<count<<endl;
            }
            count=0;
        }

    }
    getch();
}

