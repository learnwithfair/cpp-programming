#include<iostream>
#include<conio.h>
using namespace std;
double dis(double l,double w)
{
    double area;
    return area=l*w;
}
int main()
{
    double l,w;
    cout<<"Enter length : ";
    cin>>l;
    cout<<"Enter Weight : ";
    cin>>w;

    cout<<"Rectangular area is "<< dis(l,w);
    getch();


}
