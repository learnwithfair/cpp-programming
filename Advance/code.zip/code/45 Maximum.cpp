#include<iostream>
#include<conio.h>
#include<iomanip>
using namespace std;
int main()
{
    int num[30],n,i,max,pos;
    cout<<"How many term : ";
    while((cin>>n)!=0)
    {
        pos=1;
        cout<<"\nEnter Element : ";
        for(i=0;i<n;i++)
        {
            cin>>num[i];

        }
        max=num[0];
        for(i=1;i<n;i++)
        {
            if(max<num[i])
            {
                max=num[i];
                pos++;
            }

        }
        cout<<"\nMaximum value of array is "<<max<<" Find in "<<pos<<" number position";
        cout<<"\n\nHow many term : ";
    }
    getch();
}
