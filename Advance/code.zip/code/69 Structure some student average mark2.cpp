#include<iostream>
#include<string.h>
#include<stdio.h>
#include<conio.h>
#include<iomanip>
using namespace std;
class student
{
public:

    char name[20];//char variable
    int mark1;
    int mark2;
    int mark3;
};
int main()
{
    student s[20];
    int n,i;
    double avg[20];
    cout<<"How many student : ";
    cin>>n;
    for(i=0; i<n; i++)
    {
        cout<<"Enter "<<i+1<<" number student Information : \n\n";
        cout<<"Enter student name : ";
        cin>>s[i].name;
        //gets(s.name[i]);
        cout<<"Enter First subject mark : ";
        cin>>s[i].mark1;
        cout<<"Enter Second subject mark : ";
        cin>>s[i].mark2;
        cout<<"Enter Third subject mark : ";
        cin>>s[i].mark3;
    }
    for(i=0; i<n; i++)
    {
        avg[i]=(s[i].mark1+s[i].mark2+s[i].mark3)/double(n);
    }
    for(i=0;i<n;i++)
    {
        cout<<i+1<<" number student Information : \n\n";
        cout<<"student name : "<<s[i].name<<endl;
        cout<<"Mark1 : "<<s[i].mark1<<endl;
        cout<<"Mark2 : "<<s[i].mark2<<endl;
        cout<<"Mark3 : "<<s[i].mark3<<endl;
        cout<<fixed<<setprecision(2);
        cout<<"Total average subject mark : "<<avg[i]<<"\n\n";

    }
    getch();


}
