#include<iostream>
#include<conio.h>
#include<iomanip>
using namespace std;
int main()
{
    int n,m,r;
    cout<<"Enter First number : ";
    cin>>n;
    cout<<"Enter First number : ";
    cin>>m;
    r=n^m;
    //i000
    //0i00
    //-----bijor songkhok one thakle one
    //ii00
    cout<<"Result of the Bit wise OR gate "<<r;
    getch();
}
