#include<iostream>
#include<stdio.h>
#include<conio.h>
#include<string.h>
using namespace std;
int main()
{
    char str[20],str2[20];
    int len,i,j;
    cout<<"Enter First String : ";
    gets(str);
    cout<<"Enter Second String : ";
    gets(str2);
    len=strlen(str);
    i=0;
    while(str[i]!='\0')
    {
        str[len+i]=str2[i];
        i++;
    }
    cout<<str;
    getch();
}
