#include<iostream>
#include<conio.h>
#include<iomanip>
#include<math.h>
using namespace std;
int main()
{
    int num[30],n,i;
    double avg;
    cout<<"How many term : ";
    while((cin>>n)!=0)
    {
        avg=0.0;
        cout<<"\nEnter Element : ";
        for(i=0; i<n; i++)
        {
            cin>>num[i];
            avg=avg+num[i];
        }
        avg=avg/n;
        cout<<fixed<<setprecision(3);
        cout<<"\naverage value is "<<avg;
        cout<<"\n\nHow many term : ";
    }
    getch();
}
