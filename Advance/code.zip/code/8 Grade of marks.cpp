#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    int mark;
    cout<<"Enter any mark : ";
    while((cin>>mark)!=0)
    {
        if(mark>100||mark<0)
        {
            cout<<"Invalid result"<<endl;
        }
        else if(mark>=80)
        {
            cout<<"A+"<<endl;
        }
        else if(mark>=70)
        {
            cout<<"A"<<endl;
        }
        else if(mark>=60)
        {
            cout<<"A-"<<endl;
        }
        else if(mark>=50)
        {
            cout<<"B"<<endl;
        }
        else if(mark>=40)
        {
            cout<<"C"<<endl;
        }
        else if(mark>=33)
        {
            cout<<"D"<<endl;
        }
        else
            cout<<"Fail"<<endl;
        cout<<"Enter any mark : ";
    }
    getch();
}
