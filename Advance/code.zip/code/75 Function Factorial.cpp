#include<iostream>
#include<conio.h>
#include<iomanip>
using namespace std;
int dis(int n)
{
    int fact=1,i;
    for(i=1; i<=n; i++)
    {
        fact=fact*i;
    }
    return fact;
}
int main()
{
    int n;
    while(1)
    {
        cout<<"Enter any integer number : ";
        cin>>n;
        cout<<"Factorial number of the "<<n<<" is "<<dis(n)<<"\n\n";

    }
    getch();
}
