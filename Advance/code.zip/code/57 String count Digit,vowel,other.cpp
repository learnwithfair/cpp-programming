#include<iostream>
#include<conio.h>
#include<string.h>
#include<stdio.h>
using namespace std;
int main()
{
    char str[30],ch;
    int i,vowel,consonant,digit,word,other;
    i=vowel=consonant=digit=word=other=0;
    cout<<"Enter any string : ";
    gets(str);
    while((ch=str[i])!='\0')
    {
        if(ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u'
                ||ch=='A'||ch=='E'||ch=='I'||ch=='O'||ch=='U')
            vowel++;
        else if(ch>='a'&&ch<='z'||ch>='A'&&ch<='Z')
            consonant++;
        else if(ch>='0'&&ch<='9')
        {
            digit++;
        }
        else if(ch==' ')
            word++;
        else
            other++;
        i++;
    }
    word++;
    cout<<endl<<"Consonant : "<<consonant<<endl;
    cout<<"Vowel : "<<vowel<<endl;
    cout<<"digit : "<<digit<<endl;
    cout<<"word : "<<word<<endl;
    cout<<"other : "<<other<<endl;
    getch();
}
