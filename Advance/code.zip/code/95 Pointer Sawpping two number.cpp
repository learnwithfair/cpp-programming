#include<iostream>
#include<conio.h>
using namespace std;
main()
{
    while(1)
    {
        int num1,num2,tem;
        int *p1,*p2;
        cout<<"Enter First number : ";
        cin>>num1;
        cout<<"Enter Second number : ";
        cin>>num2;

        p1=&num1;
        p2=&num2;
        cout<<"\nBefore Swapping:\n\nThe First number = "<<*p1<<"\n";
        cout<<"The Second  number = "<<*p2<<"\n\n";
        tem=*p1;
        *p1=*p2;
        *p2=tem;
        cout<<"After Swapping:\n\nThe First number = "<<*p1<<"\n";
        cout<<"The Second  number = "<<*p2<<"\n\n";
    }
    getch();
}
