#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    long long int n,rev,i;
    cout<<"Enter any number : ";
    while((cin>>n)!=0)
    {
        cout<<"\nReverse number is ";
        while(n!=0)
        {
            rev=n%10;
            cout<<rev;
            n=n/10;
        }
        cout<<"\n\nEnter any number : ";

    }
    getch();
}
