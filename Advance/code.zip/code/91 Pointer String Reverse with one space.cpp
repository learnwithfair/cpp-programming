#include<iostream>
#include<stdio.h>
#include<conio.h>
#include<string.h>
using namespace std;
main()
{
    while(1)
    {
        char str[20],*p,str2[20];
        int i,len,j;
        cout<<"Enter any String : ";
        gets(str);
        len=strlen(str);
        i=len-1;
        j=0;
        p=&str[len-1];
        while(str[i]>'\0')
        {

            str2[j]=*p;
            i--;
            j++;
            p--;

        }
        str2[j]='\0';
        cout<<"\n\nReverse String with one space is : ";
        for(i=0; i<len; i++)
        {
            cout<<str2[i]<<" ";
        }
        cout<<"\n\n";
    }

    getch();
}
