#include<iostream>
#include<stdio.h>
#include<conio.h>
#include<string.h>
using namespace std;
int main()
{
    char n[20],b[20];
    cout<<"Enter First String : ";
    gets(n);
    cout<<"Enter Second String : ";
    gets(b);
    strcat(n,b);
    cout<<n;
    getch();
}
