#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    int num,i,j;
    cout<<"Enter any term : ";
    while((cin>>num)!=0)
    {
        cout<<"\nThese prime numbers are : ";
        for(i=1;i<=num;i++)
        {
            for(j=2;j<=i;j++)
            {
                if(i%j==0)
                    break;
            }
            if(i==j)
                cout<<i<<" ";
        }
        cout<<"\n\nEnter any term : ";

    }
    getch();
}
