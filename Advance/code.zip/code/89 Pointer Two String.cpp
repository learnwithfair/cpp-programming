#include<iostream>
#include<conio.h>
#include<string.h>
#include<stdio.h>
using namespace std;
main()
{
    char str1[20],str2[20];
    int i,len1,len2,*p1,*p2;
    while(1)
    {
        cout<<"Enter First String : ";
        gets(str1);
        cout<<"Enter Second String : ";
        gets(str2);
        len1=strlen(str1);
        len2=strlen(str2);
        p1=&len1;
        p2=&len2;
        if(*p1>*p2)
        {
            cout<<"Maximum String is "<<str1<<"\n\n";
        }
        else if(*p1==*p2)
            cout<<"Two string are same"<<"\n\n";
        else
            cout<<"Maximum String is "<<str2<<"\n\n";
    }
    getch();
}
