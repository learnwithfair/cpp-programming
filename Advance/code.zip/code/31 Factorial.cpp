#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    int i,fact,n;
    cout<<"Enter any number : ";
    while((cin>>n)!=0)
    {
        cout<<endl;
        fact=1;
        for(i=1; i<=n; i++)
        {
            fact=fact*i;
        }
        cout<<"Factorial value is "<<fact;
        cout<<"\n\nEnter any number : ";
    }
    getch();

}
