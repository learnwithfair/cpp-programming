#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    int num[30],n,pos,i,j,r,u,num2[30];
    cout<<"How many number : ";
    while((cin>>n)!=0)
    {
        u=0;
        cout<<"\n\nEnter any Elements : ";
        for(i=0; i<n; i++)
        {
            cin>>num[i];

        }
        cout<<"\n\narray numbers are : ";
        for(i=0; i<n; i++)
            cout<<num[i]<<" ";
        cout<<"\n\nEnter Position for Insert number in array : ";
        cin>>pos;
        cout<<"\n\nEnter Insert number in array : ";
        cin>>r;
        cout<<"\n\nReplace array numbers are : ";
        for(i=0,j=0; i<=n,j<=n;i++,j++)
        {
            if(pos==i+1)
            {
                u++;
                num2[j]=r;
            }
            else
            {
                if(u==0)
                {
                    num2[j]=num[i];
                }
                else
                    num2[j]=num[i-1];
            }

        }
        for(j=0; j<=n; j++)
            cout<<num2[j]<<" ";
            cout<<"\n\nHow many number : ";

    }
    getch();
}
