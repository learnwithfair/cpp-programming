#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    int year;
    cout<<"Enter any year : ";
    while((cin>>year)!=0)
    {
        if (year%400==0||(year%4==0&&year%100!=0))
        {
            cout<<"Leap year"<<endl;
        }
        else
            cout<<"Not Leap year"<<endl;
        cout<<"Enter any year : ";
    }
    getch();

}
