#include<iostream>
#include<stdio.h>
#include<conio.h>
#include<string.h>
using namespace std;
int main()
{
    char str[20],ch;
    int len,i,j;
    cout<<"Enter any string : ";
    gets(str);
    strlwr(str);
    len=strlen(str);
    for(i=0;i<len-1;i++)
    {
        for(j=i+1;j<len;j++)
        {
            if(str[i]>str[j])
            {
                ch=str[i];
                str[i]=str[j];
                str[j]=ch;
            }
        }
    }
    cout<<"Alphabetic order is :";
    i=0;
    while(str[i]!='\0')
    {
        cout<<str[i]<<" ";
        i++;
    }

    getch();
}
