#include<iostream>
#include<conio.h>
#include<iomanip>
using namespace std;
int main()
{
    int n,m,r;
    cout<<"Enter First number : ";
    cin>>n;
    //i00
    //i0i
    //------
    //i00

    cout<<"Enter First number : ";
    cin>>m;
    r=n&m;
    cout<<"Result of the bitwise and gate "<<r;
    getch();
}
