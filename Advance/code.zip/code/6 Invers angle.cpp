#include<iostream>
#include<conio.h>
#include<math.h>
#include<iomanip>
using namespace std;
int main()
{
    double n,r,r2,pi=3.1416;
    cout<<"Enter any angle " ;
    cin>>n;
    //r=asin(n);
    //r=asin(n*pi/180);

    r=asin(n)*180/pi;
    r2=acos(n)*180/pi;
    cout<<fixed<<setprecision(2);
    cout<<"angle of the Sin Inverse is "<<r<<endl;
    cout<<"angle of the Cos Inverse is "<<r2;
    getch();
}

