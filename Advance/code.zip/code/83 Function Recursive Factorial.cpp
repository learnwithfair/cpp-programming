#include<iostream>
#include<conio.h>
using namespace std;
int fact(int n)
{
    int i;
    if(n==1)
        return 1;
    else
        return n*fact(n-1);
}
int main()
{
    int n;
    while(1)
    {
        cout<<"Enter any number : ";
        cin>>n;
        cout<<"The number of Factorial value is "<<fact(n)<<"\n\n";

    }
    getch();
}
