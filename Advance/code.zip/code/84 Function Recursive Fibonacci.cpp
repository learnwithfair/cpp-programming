#include<iostream>
#include<conio.h>
using namespace std;
int fibo(int n)
{
    if(n==1)
        return 0;
    else if (n==2)
        return 1;
    else
        return fibo(n-1)+fibo(n-2);
}
int main()
{
    int n;
    while(1)
    {
        cout<<"Enter any position : ";
        cin>>n;
        cout<<n<<" number Position of Fibonacci number is "<<fibo(n)<<"\n\n";

    }
    getch();
}

