#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    int a[20][20],b[20][20],row1,col1,row2,col2,i,j,sum=0,mul=0,k;
    cout<<"Enter Row for A matrix : ";
    cin>>row1;
    cout<<"Enter Column for A matrix : ";
    cin>>col1;
    cout<<"\nEnter Element for A Matrix : \n";
    for(i=0; i<row1; i++)
    {
        cout<<"\n\nEnter Element of "<<i+1<<" number Row for A matrix : \n";
        for(j=0; j<col1; j++)
        {
            cout<<"A["<<i<<"]["<<j<<"] : ";
            cin>>a[i][j];
        }
    }



    cout<<"\nEnter Row for B matrix : ";
    cin>>row2;
    while(row1!=row2)
    {
        cout<<"\n\nSorry A matrix Row & B matrix Row number is not Same.\nPlease Enter same value for (A+B) Matrix Summation.\n";
        cout<<"\nEnter Row for B matrix : ";
        cin>>row2;
    }
    cout<<"\nEnter Column for B matrix : ";
    cin>>col2;
    while(col1!=col2)
    {
        cout<<"\n\nSorry A matrix column & B matrix Column number is not Same.\nPlease Enter same value for (A+B) Matrix Summation.\n";
        cout<<"\nEnter Column for B matrix : ";
        cin>>col2;
    }
    cout<<"\n\nEnter Element for B Matrix : \n";
    for(i=0; i<row2; i++)
    {
        cout<<"\n\nEnter Element of "<<i+1<<" number Row for B matrix : \n";
        for(j=0; j<col2; j++)
        {
            cout<<"B["<<i<<"]["<<j<<"] : ";
            cin>>b[i][j];
        }
    }
    //
    cout<<"\n\nA Matrix is : \n\t\t";
    for(i=0; i<row1; i++)
    {
        for(j=0; j<col1; j++)
        {
            cout<<a[i][j]<<" ";
        }
        cout<<endl<<"\t\t";
    }
    //
    cout<<"\n\nB Matrix is : \n\t\t";
    for(i=0; i<row2; i++)
    {
        for(j=0; j<col2; j++)
        {
            cout<<b[i][j]<<" ";
        }
        cout<<endl<<"\t\t";
    }
    //sum
    cout<<"\n\nMatrix Summation : \n\t\t";
    for(i=0; i<row2; i++)
    {
        for(j=0; j<col2; j++)
        {
            sum=a[i][j]+b[i][j];
            cout<<sum<<" ";
        }
        cout<<endl<<"\t\t";
    }
    //mul
    if(col1!=row2)
        cout<<"\n\nMatrix Multiplication is not Possible.\n";
    else
    {
        cout<<"\n\nMatrix Multiplication : \n\t\t";
        for(i=0; i<row1; i++)
        {
            for(j=0; j<col2; j++)
            {
                for(k=0; k<row2; k++)
                {
                    mul=mul+a[i][k]*b[k][j];

                }
                cout<<mul<<" ";
                mul=0;

            }
            cout<<endl<<"\t\t";
        }
    }


    getch();

}
