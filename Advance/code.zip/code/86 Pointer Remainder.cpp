#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    int num1,num2,red;
    int *p1,*p2;
    while(1)
    {
        cout<<"Enter First number : ";
        cin>>num1;
        cout<<"Enter Second number : ";
        cin>>num2;
        p1=&num1;
        p2=&num2;
        red=*p1 % *p2;
        cout<<"Remainder Result is "<<red<<"\n\n";
    }
    getch();


}

