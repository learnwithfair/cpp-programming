#include<iostream>
#include<fstream>
#include<conio.h>
#include<string.h>
using namespace std;
int main()
{
    ofstream file;
    int i;
    file.open("One to ten Write.txt",ios::out|ios::app);
    for(i=1;i<=10;i++)
    {
        file<<i<<endl;
    }
    cout<<"Data is stored\n";
    file.close();
    getch();
}
