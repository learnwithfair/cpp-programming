#include<iostream>
#include<conio.h>
#include<math.h>
#include<iomanip>
using namespace std;
int main()
{
    double a,b,c,result,x2,x3,r;
    cout<<"Enter value of a : ";
    cin>>a;
    cout<<"Enter value of b : ";
    cin>>b;
    cout<<"Enter value of c : ";
    cin>>c;
    r=b*b-4*a*c;
    if(r<0)
    {
        cout<<"This is Imaginary number";
    }
    else
    {
        x2=(-b+sqrt(r))/(2*a);
        x3=(-b-sqrt(r))/(2*a);
        cout<<fixed<<setprecision(2);
        cout<<"Value of the Equation are X1 = "<<x2<<", X2 = "<<x3;
    }

    getch();
}
