#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    int num;
    cout<<"Enter any number : ";
    while((cin>>num)!=0)
    {

    }
}
