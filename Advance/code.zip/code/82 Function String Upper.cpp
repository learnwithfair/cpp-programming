#include<iostream>
#include<conio.h>
#include<stdio.h>
#include<string.h>
using namespace std;
void dis(char str[],int len)
{
    strupr(str);
    cout<<"Upper case String is "<<str<<"\n\n";
}
main()
{
    char str[40];
    int len;
    while(1)
    {
        cout<<"Enter any String : ";
        gets(str);
        len=strlen(str);
        cout<<"\nString is "<<str<<"\n\n";
        dis(str,len);

    }
    getch();
}

