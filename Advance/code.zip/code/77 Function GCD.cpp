#include<iostream>
#include<conio.h>
using namespace std;
int dis(int num1,int num2)

{
    int tem;
    while(num2!=0)
    {
        tem=num1%num2;
        num1=num2;
        num2=tem;
    }
    return num1;
}
int main()
{
    int num1,num2;
    while(1)
    {
        cout<<"Enter First number : ";
        cin>>num1;
        cout<<"Enter second number : ";
        cin>>num2;
        cout<<"These number of the GCD is "<<dis(num1,num2)<<"\n\n";
    }
    getch();
}
