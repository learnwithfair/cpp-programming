#include<iostream>
#include<conio.h>
using namespace std;
int dis(int n,int r)
{
    int i,npr=1,fact=1,ncr;
    for(i=1; i<=r; i++)
    {
        npr=npr*n;
        n--;
    }
    for(i=1; i<=r; i++)
    {
        fact=fact*i;
    }
    return ncr=npr/fact;

}
int main()
{
    int n,r;
    while(1)
    {
        cout<<"Enter value of n : ";
        cin>>n;
        cout<<"Enter value of r : ";
        cin>>r;
        cout<<n<<"C"<<r<<" value is "<<dis(n,r)<<"\n\n";
    }
    getch();

}

