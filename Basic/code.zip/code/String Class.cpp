#include<iostream>
#include<conio.h>
#include<string.h>
using namespace std;
int main()
{
    while(1)
    {
        string str,str2,str3;
        cout<<"Enter First String : ";
        //gets(str);
        cin>>str;
        cout<<"Enter Second String : ";
        cin>>str2;

        str3=str;
        cout<<"Str3 = "<<str3<<endl;
        str3=str+str2;
        cout<<"str + str2 = "<<str3<<endl;
    }
    getch();

}
