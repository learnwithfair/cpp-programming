#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    int num2,num3,red;
    cout<<"Enter First number : ";
    cin>>num2;
    cout<<"Enter second number : ";
    cin>>num3;
    red=num2%num3;
    cout<<"These Remainder number is "<<red;
    getch();

}
