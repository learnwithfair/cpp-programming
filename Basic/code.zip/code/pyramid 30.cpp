#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    int row,col,n,ncr;
    cout<<"Enter any term : ";
    while((cin>>n)!=0)
    {
        cout<<endl;
        for(row=0;row<n;row++)
        {
            for(col=0;col<=row;col++)
            {
                if(row==0||col==0)
                {
                    ncr=1;
                    cout<<ncr<<" ";
                }
                else
                {
                    ncr=ncr*(row-col+1)/col;
                    cout<<ncr<<" ";
                }
            }
            cout<<endl;
        }
        cout<<"\n\nEnter any term : ";
    }
    getch();
}
