#include<iostream>
#include<conio.h>
#include<iomanip>

using namespace std;
int main()
{
    double r,area,pi=3.1416;
    cout<<"Enter any Radius for circle : " ;
    cin>>r;
    area=pi*r*r;
    cout<<fixed;
    //cout<<showpoint;
    cout<<setprecision(2);
    cout<<"area of the circle is "<<area;
    getch();
}
