#include<iostream>
#include<conio.h>
using namespace std;
class person
{
public:
    void overriding()
    {
        cout<<"I am person"<<endl;
    }

};
class student:public person
{
public:
    void overriding()
    {
        cout<<"I am student"<<endl;
    }
};
class teacher:public person
{
public:
    void overriding()
    {
        cout<<"I am Teacher"<<endl;
    }
};

int main()
{
    person p;
    student s;
    teacher t;
    p.overriding();
    s.overriding();
    t.overriding();
    getch();
}
