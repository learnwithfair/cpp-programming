#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    int const x=90;//constant variable

    cout<<x;
    getch();
}
