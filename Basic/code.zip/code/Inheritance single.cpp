#include<iostream>
#include<conio.h>
#include<string.h>
using namespace std;
class person//super
{
public:
    string name;
    int age;
    virtual void dis1()
    {
        cout<<"name = "<<name<<"\nage : "<<age<<endl;
    }
};
class student:public person//sub
{
public:

    int id;
    void dis2()
    {

        dis1();
        cout<<"ID : "<<id<<endl;
    }

};
int main()
{
    student s;
    person p;
    s.id=202;
    s.age=22;
    s.name="Rahatul Islam";
    s.dis2();
    getch();
}
