#include<iostream>
#include<conio.h>
using namespace std;
template <class variable1,class variable2>
variable1 dis(variable1 x,variable2 y)
{
    return x+y;
}
int main()
{
    while(1)
    {

        double r,p;
        cout<<"Enter First number : ";
        cin>>r;
        cout<<"Enter Second number : ";
        cin>>p;
        cout<<r<<" + "<<p<<" = "<<dis(p,r)<<endl;
    }

    getch();
}
/*
output:
Enter First number : 4.3
Enter Second number : 3
4.3 + 3 = 7.3
Enter First number : 5
Enter Second number : 3.4
5 + 3.4 = 8.4
Enter First number : 4
Enter Second number : 5
4 + 5 = 9
*/

