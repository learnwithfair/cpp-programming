#include<iostream>
#include<fstream>
#include<conio.h>
#include<string.h>
using namespace std;
int main()
{
    int i,j,n;
    ofstream file;
    file.open("Pattern.text");//,ios::out|ios::app);
    cout<<"How many term : ";
    cin>>n;
    for(i=1;i<=n;i++)
    {
        for(j=1;j<=i;j++)
        {
            file<<i<<" ";
        }
        file<<endl;
    }
    cout<<"Data is Stored\n";
    file.close();
    getch();
}
