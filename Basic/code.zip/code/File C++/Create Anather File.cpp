#include<iostream>
#include<fstream>
#include<conio.h>
#include<string.h>
using namespace std;
int main()
{
    string line;

    ifstream file1;
    ofstream file2;
    file1.open("First File.text");
    file2.open("Second another File.text");
    while(getline(file1,line))
    {
        file2<<line<<endl;
    }
    cout<<"File write successfully in another file.\n";
    getch();


}
