#include<iostream>
#include<conio.h>
#include<fstream>
#include<string.h>
using namespace std;
int main()
{
    string line;
    ifstream file;
    file.open("Data read.txt");
    while(getline(file,line))
    {
        cout<<line<<endl;
    }
    file.close();
    getch();
}
