#include<iostream>
#include<fstream>
#include<conio.h>
#include<string.h>
using namespace std;
int main()
{
    string name;
    ofstream file;
    file.open("Student.txt");
    cout<<"Enter your name : ";
    getline(cin,name);
    file<<name;
    file.close();
    cout<<"Data is stored\n";
    getch();
}
