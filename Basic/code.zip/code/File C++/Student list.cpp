#include<iostream>
#include<conio.h>
#include<fstream>
#include<string.h>
using namespace std;
int main()
{
    string name;
    int age,n,i;
    ofstream file;
    file.open("Student List .txt",ios::out|ios::app);
    cout<<"How many student : ";
    cin>>n;
    for(i=0; i<n; i++)
    {
        cout<<"Enter Student name : ";
        cin.ignore();
        getline(cin,name);
        file<<name<<"\t";
        cout<<"Enter Student age : ";
        cin>>age;
        file<<age<<endl;

    }
    cout<<"Data is stored\n";
    file.close();
    getch();
}
