#include<iostream>
#include<fstream>
#include<conio.h>
#include<stdio.h>
#include<string.h>
using namespace std;
main()
{
    string line;
    ifstream file;
    file.open("Read Upper case.text");
    while(getline(file,line))
    {
        //strupr(line);
        cout<<line<<endl;
    }
    cout<<"\n\nFile is successfully opened\n";
    getch();
}
