#include<iostream>
#include<conio.h>
#include<fstream>
#include<string.h>
using namespace std;
int main()
{
    while(1)
    {
        string name;
        int age;
        ofstream file;
        file.open("apparent.txt",ios::out|ios::app);
        cout<<"Enter your name : ";
        getline(cin,name);
        file<<name<<"\t";
        cout<<"Enter your age : ";
        cin>>age;
        file<<age<<endl;
        file.close();
        cout<<"Data is stored\n";
        cin.ignore();
    }
    getch();
}
