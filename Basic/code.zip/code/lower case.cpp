#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    char ch;
    cout<<"Enter upper case character : ";
    cin>>ch;
    ch=ch+32;
    cout<<"Lower case character is "<<ch;
    getch();
}
