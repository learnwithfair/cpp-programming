#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    int num1,num2,GCD;
    cout<<"Enter First number : ";
    cin>>num1;
    cout<<"Enter Second number : ";
    cin>>num2;
    while(num2!=0)
    {
        GCD=num1%num2;
        num1=num2;
        num2=GCD;
    }
    cout<<"Value of the GCD is "<<num1;
    getch();

}
