#ifndef STUDENT_H
#define STUDENT_H


class student
{
    public:
        void display();

};

#endif // STUDENT_H
