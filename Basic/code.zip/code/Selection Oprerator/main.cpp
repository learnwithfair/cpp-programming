#include <iostream>
#include "student.h"

using namespace std;

int main()
{
    student ob;
    student *p=&ob;
    p->display();//Selection Operator
    return 0;
}
