#include "student.h"
#include <iostream>

using namespace std;

void student::display()
{
    cout<<"Function is called\n";
}
