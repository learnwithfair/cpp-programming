#include<iostream>
#include<conio.h>
#include<iomanip>
using namespace std;
int main()
{
    double f,c;
    cout<<"Enter any Celsius Temperature : ";
    cin>>c;
    f=9/(double)5*c+32;
    cout<<"Fahrenheit Temperature is "<<f;
    getch();
}
