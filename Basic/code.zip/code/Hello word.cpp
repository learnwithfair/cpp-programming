#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    char name[30]="Rahatul Islam";
    //cout<<"Enter your name : ";
    //cin>>name;
    cout<<"My name is "<<name;
    getch();
}
