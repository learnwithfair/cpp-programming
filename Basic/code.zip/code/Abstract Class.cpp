#include<iostream>
#include<conio.h>
using namespace std;
class MobileUser
{
public:
    virtual void MessageSend()=0;
    void call()
    {
        cout<<"Hello\n";
    }
};
class Rahim:public MobileUser
{
public:
    void MessageSend()
    {
        cout<<"Hi, This is Rahim\n";
    }
};
class Karim:public MobileUser
{
public:
    void MessageSend()
    {
        cout<<"Hi, This is Karim\n";
    }
};
main()
{
    MobileUser *m;
    Rahim r;
    Karim k;
    r.call();
    m=&r;
    m->MessageSend();
    k.call();
    m=&k;
    m->MessageSend();
    getch();

}

