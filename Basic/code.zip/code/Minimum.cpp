#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    int n2,n3,n4,min;
    cout<<"Enter first number : ";
    cin>>n2;
    cout<<"Enter second number : ";
    cin>>n3;
    cout<<"Enter third number : ";
    cin>>n4;
    if(n2<n3&&n2<n4)
        cout<<"Minimum number is "<<n2;
    else if(n3<n2&&n3<n4)
        cout<<"Minimum number is "<<n3;
    else
        cout<<"Minimum number is "<<n4;
    getch();

}
