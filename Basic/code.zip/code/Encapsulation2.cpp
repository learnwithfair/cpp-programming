#include<iostream>
#include<conio.h>
#include<string.h>
using namespace std;
class student
{
public:
    string name;
    int id;
    void display()
    {
        cout<<"Name : "<<name<<endl;
        cout<<"ID : "<<id<<endl;
    }
};
int main()
{
    while(1)
    {
        student ob;

        cout<<"Enter your name : ";

        getline(cin,ob.name);

        cout<<"Enter your ID : ";
        cin>>ob.id;
        ob.display();
        cin.ignore();
    }
    getch();
}
