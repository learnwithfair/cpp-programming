#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    char ch;
    cout<<"Enter any lower case : ";
    cin>>ch;
    ch=toupper(ch);
    cout<<"Upper case character is "<<ch;
    getch();
}
