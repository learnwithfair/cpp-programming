#include<iostream>
#include<conio.h>
#include<string.h>
using namespace std;
class student
{
public:
    string name;

    student(string name)
    {
         this -> name=name;
         //name=name;this is Not Correct initialization

    }
    void dis()
    {

        cout<<name<<endl;
    }
};
int main()
{
    student ob("Rahatul Islam");
    ob.dis();
    getch();
}
