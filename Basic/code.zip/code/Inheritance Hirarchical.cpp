#include<iostream>
#include<conio.h>
using namespace std;
class student//supper
{
public:
    int id;
    virtual void dis()
    {
        cout<<"ID : "<<id<<endl;
    }
};
class rahim:public student//sup
{
public:
    string name;
    void dis2()
    {
        cout<<"Name : "<<name<<endl;
        dis();
        cout<<"\n\n";
    }
};
class karim:public student//sup
{
public:
    double gpa;
    void dis3()
    {
        dis();
        cout<<"GPA : "<<gpa<<endl;
        cout<<"\n\n";
    }
};
int main()
{


    student s;
    rahim r;
    karim k;
    string n;
    int d;
    double g;
    cout<<"Enter your name : ";
    getline(cin,n);
    cout<<"Enter your ID : ";
    cin>>(d);
    cout<<"Enter your GPA : ";
    cin>>g;
    r.id=d;
    r.name=n;
    k.id=d;
    k.gpa=g;

    r.dis2();
    k.dis3();
    getch();
}
