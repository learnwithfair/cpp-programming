#include <iostream>
#include "student.h"
using namespace std;

int main()
{
    const Student ob;
    ob.dis();
    Student ob2;
    Student *p=&ob2;
    p->dis2();
    return 0;
}
