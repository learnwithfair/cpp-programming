#ifndef STUDENT_H
#define STUDENT_H


class Student
{
    public:
        void dis() const;
        void dis2() ;
};

#endif // STUDENT_H
