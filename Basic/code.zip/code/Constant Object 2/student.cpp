#include "student.h"
#include <iostream>

using namespace std;
void Student::dis() const
{
    cout<<"Constant Variable is Called\n\n";
}
void Student::dis2()
{
    cout<<"Non-Constant Variable is Called\n\n";
}
