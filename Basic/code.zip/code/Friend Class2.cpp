#include<iostream>
#include<conio.h>
using namespace std;
class B
{
private:
    string name;
    int age;
public:
    void setvalue(string name,int age)//Use Encapsulation
    {
        this->name=name;//use this keyword
        this->age=age;
    }
    friend class C;//use Friend class
};
class C
{
public:
    void dis(B ob)//Object Received
    {
        cout<<"Name = "<<ob.name<<"\nAge : "<<ob.age<<endl;
    }
};
int main()
{
    string name;
    int age;
    cout<<"Enter your name : ";
    getline(cin,name);
    cout<<"Enter your age : ";
    cin>>age;

    B ob1;
    ob1.setvalue(name,age);
    C ob2;
    ob2.dis(ob1);
    getch();
}
