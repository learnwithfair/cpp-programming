#include<iostream>
#include<conio.h>
using namespace std;
double dis(double x,double y)
{
    return x+y;
}
int main()
{
    while(1)
    {
        double a,b;
        cout<<"Enter First number : ";
        cin>>a;
        cout<<"Enter First number : ";
        cin>>b;
        cout<<a<<" + "<<b<<" = "<<dis(a,b)<<endl;
    }
    getch();
}
/*
output :
Enter First number : 3.4
Enter First number : 5
3.4 + 5 = 8.4
Enter First number : 6
Enter First number : 5
6 + 5 = 11
Enter First number : 5
Enter First number : 4.3
5 + 4.3 = 9.3
*/
