#include<iostream>
#include<conio.h>
#include<string.h>
using namespace std;
class student
{
public:
    student (string name,int id)
    {
        cout<<"Name = "<<name<<", " <<"ID = "<<id<<", "<<endl;
    }
    student (string name,int id,double gpa)
    {
        cout<<"Name = "<<name<<", "<<"ID = "<<id<<", "<<"GPA = "<<gpa<<endl;
    }
    student ()
    {
        cout<<"No Parameter adding. It is a default Constructor"<<endl;
    }
};
main()
{
    while(1)
    {
        string name;
        int id,n;
        double gpa;
        cout<<"\n\nEnter Constructor call number : ";
        cin>>n;
        if(n==2)
        {
            cout<<"Enter your name : ";
            cin.ignore();
            getline(cin,name);
            cout<<"Enter your ID : ";
            cin>>id;
            student s(name,id);
        }
        else if(n==3)
        {
            cout<<"Enter your name : ";
            cin.ignore();
            getline(cin,name);
            cout<<"Enter your ID : ";
            cin>>id;
            cout<<"Enter your GPA : ";
            cin>>gpa;
            student s(name,id,gpa);
        }
        else if(n==0)
        {
            student s;
        }
    }
    getch();
}
