#include<iostream>
#include<conio.h>
#include<string.h>
using namespace std;
int main()
{
    char n[20];
    cout<<"Enter any string : ";
    cin>>n;
    strupr(n);
    cout<<"Upper string is : ";
    cout<<n;
    getch();
}
