#include<iostream>
#include<conio.h>
#include<iomanip>
double pi=3.1416;
using namespace std;
class shape
{
public:
    double dim1,dim2;
    shape(double dim1,double dim2)
    {
        this->dim1=dim1;
        this->dim2=dim2;
    }
    virtual double area()
    {
        return 0;
    }
};
class Triangle:public shape
{
public:
    Triangle(double dim1,double dim2)
        :shape(dim1,dim2)

    {

    }
    double area()
    {
        return 0.5*dim1*dim2;
    }
};
class Rectangle:public shape
{
public:
    Rectangle(double dim1,double dim2)
        :shape(dim1,dim2)
    {

    }
    double area()
    {
        return dim1*dim2;
    }
};
class circle//:public shape
{
public:
    double dim1;
    circle(double dim1)
    //:shape(dim1,dim2)
    {
        this->dim1=dim1;

    }
    double area()
    {
        return ::pi*dim1*dim1;
    }
};

int main()
{
    double dim1,dim2;
    // shape p; //Wrong
    shape *p;
    cout<<"Enter Triangle length : ";
    cin>>dim1;
    cout<<"Enter Triangle Weight : ";
    cin>>dim2;
    Triangle t(dim1,dim2);
    cout<<fixed<<setprecision(2);
    cout<<"Triangle Area : "<<t.area()<<endl<<endl;

    cout<<"Enter Rectangle length : ";
    cin>>dim1;
    cout<<"Enter Rectangle Weight : ";
    cin>>dim2;
    Rectangle r(dim1,dim2);
    cout<<"Rectangle Area : "<<r.area()<<endl<<endl;

    cout<<"Enter Circle Radius : ";
    cin>>dim1;
    circle c(dim1);
    cout<<"Circle Area : "<<c.area()<<endl<<endl;

    getch();


}

