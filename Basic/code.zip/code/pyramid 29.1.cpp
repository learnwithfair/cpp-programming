#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    int n,r,row,col,p;
    cout<<"Enter any term : ";
    while((cin>>n)!=0)
    {
        cout<<endl;
        r=1;
        for(row=1; row<=n; row++)
        {
            for(col=1; col<=n-row; col++)
            {
                cout<<"  ";
            }
            for(col=1; col<=row; col++)
            {

                if(r>9)
                {
                    p=r%10;
                    cout<<" "<<p;

                }
                else
                cout<<" "<<r;
                r++;

            }
            r--;
            for(col=1; col<=row-1; col++)
            {

                r--;
                if(r>9)
                {
                    p=r%10;
                    cout<<" "<<p;

                }
                else
                cout<<" "<<r;

            }
            cout<<endl;
            r++;


        }


        //nicher ongsho
        r-=2;
        for(row=n-1; row>=1; row--)
        {
            for(col=n-row; col>=1; col--)
            {
                cout<<"  ";
            }
            for(col=row; col>=1; col--)
            {

                if(r>9)
                {
                    p=r%10;
                    cout<<" "<<p;

                }
                else
                cout<<" "<<r;
                r++;

            }
            r--;
            for(col=row-1; col>=1; col--)
            {

                r--;
                if(r>9)
                {
                    p=r%10;
                    cout<<" "<<p;

                }
                else
                cout<<" "<<r;

            }
            cout<<endl;
            r--;
        }



        cout<<"\n\nEnter any term : ";

    }
    getch();
}

