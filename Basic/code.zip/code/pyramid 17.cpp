#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    int row,col,n,i;
    cout<<"Enter any term : ";
    while((cin>>n)!=0)
    {
        i=1;
        cout<<endl;
        for(row=n;row>=1;row--)
        {
            for(col=row;col>=1;col--)
            {

                if(i==6)
                    cout<<"1 ";
                else
                {
                    if(i%2==0)
                cout<<"0 ";
                else
                    cout<<"1 ";
                }
                i++;


            }
            cout<<endl;

        }
        cout<<"\n\nEnter any term : ";

    }
}

