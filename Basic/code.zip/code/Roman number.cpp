#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    int num;
    while(1)
    {
        cout<<"Enter any number : ";
        cin>>num;
        {
            while(num!=0)
            {
                if(num>=1000)
                {
                    cout<<"m";
                    num-=1000;
                }
                else if(num>=900)
                {
                    cout<<"cm";
                    num-=900;
                }
                else if(num>=500)
                {
                    cout<<"d";
                    num-=500;
                }
                else if(num>=400)
                {
                    cout<<"cd";
                    num-=400;
                }
                else if(num>=100)
                {
                    cout<<"c";
                    num-=100;
                }
                else if(num>=90)
                {
                    cout<<"xc";
                    num-=90;
                }
                else if(num>=50)
                {
                    cout<<"l";
                    num-=50;
                }
                else if(num>=40)
                {
                    cout<<"xl";
                    num-=40;
                }
                else if(num>=10)
                {
                    cout<<"x";
                    num-=10;
                }
                else if(num>=9)
                {
                    cout<<"ix";
                    num-=9;
                }
                else if(num>=5)
                {
                    cout<<"v";
                    num-=5;
                }
                else if(num>=4)
                {
                    cout<<"iv";
                    num-=4;
                }
                else if(num>=1)
                {
                    cout<<"i";
                    num-=1;
                }
            }


        }
    }
