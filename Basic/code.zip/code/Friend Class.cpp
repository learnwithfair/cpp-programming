#include<iostream>
#include<conio.h>
using namespace std;
class B
{
private:
    string name="Rahatul Islam";
    int age=22;
public:
    friend class C;
};
class C
{
public:
    void dis(B ob)
    {
        cout<<"Name = "<<ob.name<<"\nAge : "<<ob.age<<endl;
    }
};
int main()
{
    B ob1;
    C ob2;
    ob2.dis(ob1);
    getch();
}
