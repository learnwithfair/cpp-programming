#include<iostream>
#include<conio.h>
#include<stdlib.h>
using namespace std;
int main()
{
    int randNumber,R;
    while(1)
    {
        cout<<"Enter your guess number Between 1 to 5 : ";
        cin>>R;
        randNumber=rand()%5+1;
        if(R==randNumber)
        {
            //cout<<"\nWe have won\n\n\n";
            cout<<"\nYES\n\n\n";
        }
        else
        {
            //cout<<"\nWe have loss.Please try again.\n\n\n";
            cout<<"\NO\n\n\n";
            cout<<"\nYour Guess number was "<<randNumber<<"\n\n\n";
        }
    }

    getch();
}
