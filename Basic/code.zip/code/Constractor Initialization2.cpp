#include<iostream>
#include<conio.h>
using namespace std;
class student
{
public:
    const int admissionFee;
    const int ExamFee;
    int ID;
    student (int x,int y,int z)
    :admissionFee(x),ExamFee(y)
    {
        ID=z;
        cout<<"ID " <<z<<endl;//Non-Constant Variable
        cout<<"admission Fee " <<x<<endl;//Constant Variable
        cout<<"Exam Fee " <<y<<endl;
    }
};
int main()
{
    student ob(39000,400,202);
    getch();
}
