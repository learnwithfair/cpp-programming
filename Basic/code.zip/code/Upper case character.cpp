#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    char ch;
    cout<<"Enter any lower case : ";
    cin>>ch;
    ch=ch-32;
    cout<<"Upper case number is "<<ch;
    getch();

}
