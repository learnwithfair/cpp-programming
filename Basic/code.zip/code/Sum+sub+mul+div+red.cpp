#include<iostream>
#include<conio.h>
#include<iomanip>
using namespace std;
int main()
{
    double n2,n3;
    cout<<"Enter two number : ";
    cin>>n2>>n3;
    double sum=n2+n3;
    double mul=n2*n3;
    double sub=n2-n3;
    double div=(double)n2/n3;
    //int red=n2%n3;
    cout<<setprecision(9);
    cout<<showpoint;

    cout<<setw(20);
    cout<<"sum : "<<sum<<setw(20)<<endl;
    //cout<<setw(20);
    cout<<fixed;
    cout<<"multiplication : "<<mul<<setw(20)<<endl;
    //cout<<setw(20);
    cout<<noshowpoint;
    cout<<"sub : "<<sub<<setw(20)<<endl;
   // cout<<setw(20);

    cout<<"division : "<<div<<setw(20)<<endl;

    getch();
}
