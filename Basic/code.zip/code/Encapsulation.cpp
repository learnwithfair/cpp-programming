#include<iostream>
#include<conio.h>
using namespace std;
class student
{
private:
    string name;
    int id;
    public:
    void setvalue(string x ,int y)
    {
        name=x;
        id=y;
    }
    void getvalue()
    {
        //return name;
        cout<<name<<endl<<id<<endl;
    }
};
int main()
{
    student ob;
    //ob.name("Rahatul Islam");//Not Correct
    ob.setvalue("Rahatul Islam",202);
    ob.getvalue();

    getch();

}
