#include<iostream>
#include<conio.h>
using namespace std;
class person
{
public:
    virtual void dis()
    {
        cout<<"I am a Person\n";
    }
};
class student:public person
{
public:
    void dis()
    {
        cout<<"I am a Student\n";
    }
};
class teacher:public student
{
public:
    void dis()
    {
        cout<<"I am a Teacher\n";
    }
};
main()
{
    person p;
    person *r=&p;
    student s;
    teacher t;
    r->dis();
    r=&s;
    r->dis();
    r=&t;
    r->dis();

    getch();
}

