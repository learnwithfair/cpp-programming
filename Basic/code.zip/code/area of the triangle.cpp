#include<iostream>
#include<conio.h>
#include<iomanip>
using namespace std;
int main()
{
    double length,weight,area;
    cout<<"Enter any length of the triangle : ";
    cin>>length;
    cout<<"Enter any Weight of the triangle : ";
    cin>>weight;
    area=length*weight;
    cout<<fixed<<setprecision(3);
    cout<<"area of the Triangle is "<<area;
    getch();
}
