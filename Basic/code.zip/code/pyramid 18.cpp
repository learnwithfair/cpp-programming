#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    int row,col,r,n;
    cout<<"Enter any term : ";
    while((cin>>n)!=0)
    {

        cout<<endl;
        for(row=1; row<=n; row++)
        {
            r=1;
            for(col=1; col<=n-row; col++)
            {
                cout<<"  ";
            }
            for(col=1; col<=row; col++)
            {
                cout<<r<<" ";
                r++;
            }
            //
            r--;

            for(col=1; col<=row-1; col++)
            {
                r--;
                cout<<r<<" ";

            }
            cout<<endl;
        }
        cout<<"\n\nEnter any term : ";
    }
}
