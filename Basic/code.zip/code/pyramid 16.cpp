#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    int row,col,n,i;
    cout<<"Enter any term : ";
    while((cin>>n)!=0)
    {
        i=1;
        for(row=n;row>=1;row--)
        {
            for(col=row;col>=1;col--)
            {

                if(i%2==0)
                cout<<"1 ";
                else
                    cout<<"0 ";
                i++;
            }
            cout<<endl;

        }
        cout<<"\n\nEnter any term : ";

    }
}
