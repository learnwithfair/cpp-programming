#include<iostream>
#include<conio.h>
using namespace std;
class person//supper
{
public:
    string name;
    void dis()
    {
        cout<<"Name : "<<name<<endl;
    }
};
class student//supper
{
public:
    int id;
    void dis2()
    {
        cout<<"ID : "<<id<<endl;
    }
};
class rahim:public person,public student//sup
{
public:
    double gpa;
    void dis3()
    {
        dis();
        dis2();
        cout<<"GPA : "<<gpa<<endl;
    }
};
int main()
{
    while(1)
    {
        rahim r;
        string name;
        int id;
        double gpa;
        cout<<"Enter your name : ";
        getline(cin,name);
        cout<<"Enter your ID : ";
        cin>>id;
        cout<<"Enter your GPA : ";
        cin>>gpa;
        r.name=name;
        r.id=id;
        r.gpa=gpa;
        r.dis3();
        cin.ignore();
        cout<<"\n\n";
    }
    getch();
}
