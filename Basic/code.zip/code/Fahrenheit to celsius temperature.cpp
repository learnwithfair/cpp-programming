#include<iostream>
#include<conio.h>
#include<iomanip>
using namespace std;
int main()
{
    double f,c;
    cout<<"Enter any Fahrenhiet Temperature : ";
    cin>>f;
    c=5/(double)9*(f-32);
    cout<<"Celsius Temperature is "<<c;
    getch();
}
