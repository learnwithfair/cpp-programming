#include<iostream>
#include<conio.h>
using namespace std;
class student
{
public:
    int id;
    float gpa;
    //Parameter Constructor with Parameter
    student(int x,float y)
    {
        id=x;
        gpa=y;
        cout<<"Parameter Constructor is opened\n";
    }
    //default Constructor.no Parameter
    student()
    {
        cout<<"default Constructor is Opened\n";
    }
    void dis()
    {

        cout<<"Function is Opened\n";
        cout<<id<<" "<<gpa<<endl;

    }
};
main()
{
    student rohim(202,3.23);
    student ob;
    rohim.dis();

    getch();


}
