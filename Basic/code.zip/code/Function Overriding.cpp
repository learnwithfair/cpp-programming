#include<iostream>
#include<conio.h>
using namespace std;
class person
{
public:
    virtual void dis()
    {
        cout<<"I am a Person\n";
    }
};
class student:public person
{
public:
    void dis()
    {
        cout<<"I am a Student\n";
    }
};
class teacher:public student
{
public:
    void dis()
    {
        cout<<"I am a Teacher\n";
    }
};
main()
{
    person p;
    student s;
    teacher t;
    p.dis();
    s.dis();
    t.dis();
    getch();
}

