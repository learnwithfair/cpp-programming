#include<iostream>
#include<conio.h>
#include<string.h>
using namespace std;
int main()
{
  string name;
    cout<<"Enter any Name : ";
    getline(cin,name);
    cout<<"Lower Name : "<<(name)<<endl;
    //string uppername=(name);
    //cout<<"Upper Name : "<<uppername<<endl;
    getch();
}

