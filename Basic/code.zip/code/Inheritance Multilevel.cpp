#include<iostream>
#include<conio.h>
using namespace std;
class person//super
{
public:
    string name;
    int age;//data Hiding
   virtual void dis()
    {
        cout<<"Name : "<<name<<endl<<"Age : "<<age<<endl;
    }
};
class student:public person//sup then super
{
public:
    int id;//Data Hiding
    void dis2()
    {
        dis();
        cout<<"ID : "<<id<<endl;

    }
};
class rahim:public student//sup then supper
{
public:
    double gpa;
    void dis3()
    {
        dis2();
        cout<<"GPA : "<<gpa<<endl;
    }
};
int main()
{
    while(1)
    {
        rahim r;
        cout<<"Enter your name : ";

        getline(cin,r.name);
        cout<<"Enter your Age : ";
        cin>>r.age;
        cout<<"Enter your ID : ";
        cin>>r.id;
        cout<<"Enter your GPA : ";
        cin>>r.gpa;
        cout<<"\n\n";
        r.dis3();
        cin.ignore();
    }
    getch();

}
