#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    while(1)
    {
        int n;
        double c,f;
        cout<<"\n\nPlease Select the menu : \n\n";
        cout<<"1.Celsius to Fahrenheit Temperature.\n";
        cout<<"2.Fahrenheit to Celsius Temperature.\n\n";
        cin>>n;
        switch(n)
        {
        case 1:
            cout<<"Enter Celsius Temperature : ";
            cin>>c;
            f=(9*c/(double)5)+32;
            cout<<"Fahrenheit Temperature is "<<f<<endl;
            break;
        case 2:
            cout<<"Enter Fahrenheit Temperature : ";
            cin>>f;
            c=(5/(double)9)*(f-32);
            cout<<"Fahrenheit Temperature is "<<c<<endl;
            break;
        default:
            cout<<"Your Selected is Wrong .\n\n";

        }
    }
}
