#include<iostream>
#include<conio.h>
using namespace std;
class shape
{
public:
    double dim1,dim2;
    shape()
    {
       dim1=20;
        dim2=10;
    }
   virtual double area()
    {
        return 0;
    }
};
class Triangle:public shape
{
public:

  double area()
  {
      return 0.5*dim1*dim2;
  }
};
class Rectangle:public shape
{
public:

  double area()
  {
      return dim1*dim2;
  }
};
int main()
{
    shape p;
    Triangle t;
    Rectangle r;
    cout<<"Triangle : "<<t.area()<<endl;

    cout<<"Rectangle : "<<r.area()<<endl;
    getch();


}

