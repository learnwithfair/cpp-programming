#include<iostream>
#include<conio.h>
using namespace std;
//single class
class person
{
public:
    void dis()
    {
        cout<<"Class person Opened\n";
    }
};
class student:public person
{
public:
    void dis2()
    {
        dis();
        cout<<"Class student Opened\n";
    }
};
//multilevel class
class A
{
public:
    void dis()
    {
        cout<<"Class A opened\n";
    }
};
class B:public A
{
public:
    void dis2()
    {
        dis();
        cout<<"Class B opened\n";
    }
};
class C:public B
{
public:
    void dis3()
    {
        dis2();
        cout<<"Class C opened\n";
    }
};
int main()
{
    C c;
    B b;
    student s;
    s.dis2();
    c.dis3();
    cout<<"\n\n";
    b.dis2();
    getch();
}
