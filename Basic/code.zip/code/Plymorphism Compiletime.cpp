#include<iostream>
#include<conio.h>
using namespace std;
class person
{
public:
    void overlodding(int a,int b)
    {
        cout<<"a+b = "<<a+b<<endl;
    }
    void overlodding(int a,int b,int c)
    {
        cout<<"a+b+c = "<<a+b+c<<endl;
    }
    void overlodding()
    {
        cout<<"No adding"<<endl;
    }
};
int main()
{
    person p;
    p.overlodding(3,4);
    p.overlodding(3,4,6);
    p.overlodding();
    getch();
}
